namespace AppShoppingCenter.Views.Cinemas;

public partial class DetailDesktopPage : ContentPage
{
	public DetailDesktopPage()
	{
		InitializeComponent();
	}
}