﻿namespace AppTask.API.Libraries.Constants
{
    public class Config
    {
        public static readonly TimeSpan LimitAccessTokenCreated = TimeSpan.FromMinutes(5);
    }
}
