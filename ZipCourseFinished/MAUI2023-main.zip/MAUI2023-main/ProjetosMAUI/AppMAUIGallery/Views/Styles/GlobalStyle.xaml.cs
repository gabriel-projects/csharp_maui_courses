namespace AppMAUIGallery.Views.Styles;

public partial class GlobalStyle : ContentPage
{
	public GlobalStyle()
	{
		InitializeComponent();
	}
}