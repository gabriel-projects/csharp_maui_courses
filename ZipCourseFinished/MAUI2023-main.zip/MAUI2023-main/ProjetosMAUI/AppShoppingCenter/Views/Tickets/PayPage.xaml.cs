namespace AppShoppingCenter.Views.Tickets;

public partial class PayPage : ContentPage
{
	public PayPage()
	{
		InitializeComponent();
	}
}