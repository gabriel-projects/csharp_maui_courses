namespace AppShoppingCenter.Views.Cinemas;

public partial class ListPage : ContentPage
{
	public ListPage()
	{
		InitializeComponent();
	}
}