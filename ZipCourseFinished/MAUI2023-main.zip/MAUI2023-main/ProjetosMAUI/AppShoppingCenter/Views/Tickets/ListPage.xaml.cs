namespace AppShoppingCenter.Views.Tickets;

public partial class ListPage : ContentPage
{
	public ListPage()
	{
		InitializeComponent();
	}
}