namespace AppMAUIGallery.Views.Styles;

public partial class ApplyDerivedTypes : ContentPage
{
	public ApplyDerivedTypes()
	{
		InitializeComponent();
	}
}