namespace AppMAUIGallery.Views.Layouts;

public partial class FlexLayoutPage : ContentPage
{
	public FlexLayoutPage()
	{
		InitializeComponent();
	}
}