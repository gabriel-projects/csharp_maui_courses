namespace AppMAUIGallery.Views.Shells.Pages;

public partial class Page04 : ContentPage
{
	public Page04()
	{
		InitializeComponent();
	}
}