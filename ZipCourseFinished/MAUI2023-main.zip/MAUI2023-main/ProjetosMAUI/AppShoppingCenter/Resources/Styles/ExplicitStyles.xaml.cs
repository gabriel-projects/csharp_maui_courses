namespace AppShoppingCenter.Resources.Styles;

public partial class ExplicitStyles : ResourceDictionary
{
	public ExplicitStyles()
	{
		InitializeComponent();
	}
}