namespace AppShoppingCenter.Views.Restaurants;

public partial class DetailPage : ContentPage
{
	public DetailPage()
	{
		InitializeComponent();
	}
}