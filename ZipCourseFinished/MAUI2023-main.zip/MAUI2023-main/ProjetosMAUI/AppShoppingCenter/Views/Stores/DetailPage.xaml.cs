namespace AppShoppingCenter.Views.Stores;

public partial class DetailPage : ContentPage
{
	public DetailPage()
	{
		InitializeComponent();
	}
}