namespace AppMVVMCommunityToolkit.Views;

public partial class PubSubPage : ContentPage
{
	public PubSubPage()
	{
		InitializeComponent();
	}
}