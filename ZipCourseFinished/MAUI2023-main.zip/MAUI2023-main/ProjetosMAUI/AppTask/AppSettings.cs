﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppTask
{
    internal class AppSettings
    {
        public static string EndpointAPI = "https://localhost:7280/api/";
    }
}
