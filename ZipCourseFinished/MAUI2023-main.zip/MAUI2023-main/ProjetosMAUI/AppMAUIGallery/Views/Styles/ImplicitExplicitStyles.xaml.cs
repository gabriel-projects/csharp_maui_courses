namespace AppMAUIGallery.Views.Styles;

public partial class ImplicitExplicitStyles : ContentPage
{
	public ImplicitExplicitStyles()
	{
		InitializeComponent();
	}
}