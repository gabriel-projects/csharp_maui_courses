namespace AppMAUIGallery.Views.Cells;

public partial class EntryCellPage : ContentPage
{
	public EntryCellPage()
	{
		InitializeComponent();
	}
}