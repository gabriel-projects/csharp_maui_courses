namespace AppMAUIGallery.Views.Layouts;

public partial class StackLayoutPage : ContentPage
{
	public StackLayoutPage()
	{
		InitializeComponent();
	}
}