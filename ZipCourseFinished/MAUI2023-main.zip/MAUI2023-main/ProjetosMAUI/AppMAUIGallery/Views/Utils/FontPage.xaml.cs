namespace AppMAUIGallery.Views.Utils;

public partial class FontPage : ContentPage
{
	public FontPage()
	{
		InitializeComponent();
	}
}