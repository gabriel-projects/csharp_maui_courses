using AppShoppingCenter.Services;
using ZXing.Net.Maui;

namespace AppShoppingCenter.Views.Tickets;

public partial class CameraPage : ContentPage
{
	public CameraPage()
	{
		InitializeComponent();
	}
}