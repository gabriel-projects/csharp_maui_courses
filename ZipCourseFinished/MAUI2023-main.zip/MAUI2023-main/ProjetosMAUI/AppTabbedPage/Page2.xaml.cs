namespace AppTabbedPage;

public partial class Page2 : ContentPage
{
	public Page2()
	{
		InitializeComponent();
	}
}