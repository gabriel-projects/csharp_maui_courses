namespace AppShoppingCenter.Views.Tickets;

public partial class ResultPage : ContentPage
{
	public ResultPage()
	{
		InitializeComponent();
	}
}