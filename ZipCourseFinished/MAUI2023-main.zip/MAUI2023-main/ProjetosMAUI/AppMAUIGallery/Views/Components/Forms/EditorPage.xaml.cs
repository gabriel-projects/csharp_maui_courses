namespace AppMAUIGallery.Views.Components.Forms;

public partial class EditorPage : ContentPage
{
	public EditorPage()
	{
		InitializeComponent();
	}
}