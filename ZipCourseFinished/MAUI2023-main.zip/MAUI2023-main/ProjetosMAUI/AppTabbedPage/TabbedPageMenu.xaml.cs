namespace AppTabbedPage;

public partial class TabbedPageMenu : TabbedPage
{
	public TabbedPageMenu()
	{
		InitializeComponent();
	}
}