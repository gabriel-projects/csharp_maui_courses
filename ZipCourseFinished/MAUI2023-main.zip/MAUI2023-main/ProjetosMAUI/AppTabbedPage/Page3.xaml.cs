namespace AppTabbedPage;

public partial class Page3 : ContentPage
{
	public Page3()
	{
		InitializeComponent();
	}
}