namespace AppShoppingCenter.Views.Restaurants;

public partial class ListPage : ContentPage
{
	public ListPage()
	{
		InitializeComponent();
	}
}