namespace AppMAUIGallery.Views.Components.Visuals;

public partial class FramePage : ContentPage
{
	public FramePage()
	{
		InitializeComponent();
	}
}