namespace AppMAUIGallery.Views.Cells;

public partial class ViewCellPage : ContentPage
{
	public ViewCellPage()
	{
		InitializeComponent();
	}
}