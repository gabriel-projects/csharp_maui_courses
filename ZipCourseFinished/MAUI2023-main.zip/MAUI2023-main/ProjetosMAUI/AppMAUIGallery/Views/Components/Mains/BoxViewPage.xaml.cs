namespace AppMAUIGallery.Views.Components.Mains;

public partial class BoxViewPage : ContentPage
{
	public BoxViewPage()
	{
		InitializeComponent();
	}
}