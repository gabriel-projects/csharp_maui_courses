namespace AppShoppingCenter.Views.Stores;

public partial class ListPage : ContentPage
{
	public ListPage()
	{
		InitializeComponent();
	}
}