namespace AppMAUIGallery.Views.Components.Forms;

public partial class TimePickerPage : ContentPage
{
	public TimePickerPage()
	{
		InitializeComponent();
	}
}