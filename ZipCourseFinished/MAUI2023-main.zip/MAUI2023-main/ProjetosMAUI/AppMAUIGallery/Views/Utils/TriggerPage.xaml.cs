namespace AppMAUIGallery.Views.Utils;

public partial class TriggerPage : ContentPage
{
	public TriggerPage()
	{
		InitializeComponent();
	}
}