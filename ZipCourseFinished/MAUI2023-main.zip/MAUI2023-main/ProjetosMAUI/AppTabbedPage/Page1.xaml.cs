namespace AppTabbedPage;

public partial class Page1 : ContentPage
{
	public Page1()
	{
		InitializeComponent();
	}
}